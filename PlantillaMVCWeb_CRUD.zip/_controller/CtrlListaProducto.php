<?php

require_once "MainModel.php";

class CtrlListaProducto {
	private $recurso = "_view/lista_producto.html";
	private $datos;
	
	public function __construct() {
		$model = new MainModel();
		$this->datos = $model->getDataRows("productos", ["id", "nombre", "precio"]);
	}
	
	public function renderContent() {
		include $this->recurso;
	}
}

//Los archivos de clase/libreria NO se cierran 
