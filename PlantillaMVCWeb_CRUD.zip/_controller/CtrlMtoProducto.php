<?php

require_once "MainModel.php";

class CtrlMtoProducto {
	const VISTA = "_view/mto_producto.html";
	const JS = "js/ctrlmtoproducto.js";
	private $operacion;
	
	public function __construct($operacion = null) { 
		$this->operacion = $operacion;
	}
	
	public function renderContent() {
		include self::VISTA;
	}
	
	public function renderJS() {
		include self::JS;
	}
	
	public function validaAtributos($id=null, $nombre=null, $precio=null) {
		$res = true;
		if ( !is_null($id) ) {
			$id = (int)$id;
			$res = $res && is_integer($id) && $id>0;
		}
		if ( !is_null($nombre) ) {
			$res = $res && $nombre != "";
		}
		if ( !is_null($precio) ) {
			$precio = (double)$precio;	
			$res = $res && is_double($precio) && $precio>=0;
		}
		return $res;
	}
	
	public function insertaRegistro($nombre, $precio) {
		$model = new MainModel();
		$res = $model->insertDataRow("productos", ["nombre", "precio"], [$nombre, $precio]);
		return $res;
	}
}

