<?php
require_once "MySQLAux.php";

class MainModel {
	public function getDataRows($tabla, $campos, $condicion = null, $params = null) {
		$mysql = new MySQLAux(DB_HOST, DB_BASE, DB_USR, DB_PASS);
		$datos = $mysql->selectRows($tabla, $campos, $condicion, $params);
		return $datos;
	}

	public function insertDataRow ($tabla, $campos, $params) {
		$mysql = new MySQLAux(DB_HOST, DB_BASE, DB_USR, DB_PASS);
		$res = $mysql->insertRow($tabla, $campos, $params);
		return $res>0 ;
	}
}
 
