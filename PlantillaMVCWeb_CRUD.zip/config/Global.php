<?php 

	//Redefinir directorios de inclusion de archivos PHP
	set_include_path(
		get_include_path() .
		PATH_SEPARATOR . realpath(__DIR__ . '/..') . '/_model' .
		PATH_SEPARATOR . realpath(__DIR__ . '/..') . '/_controller' .
		PATH_SEPARATOR . realpath(__DIR__ . '/..') . '/class'
	);
	
	define("SITE_URL", "http://localhost/php/5NM50/");
	define("RUTA_DEFAULT", "producto");
	define("DB_HOST", "localhost");
	define("DB_BASE", "pruebas");
	define("DB_USR", "root");
	define("DB_PASS", "toor");
	